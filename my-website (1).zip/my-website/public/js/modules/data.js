/**
 * data.js
 * Static data: Indian states and their cities.
 * Add/remove entries here — UI updates automatically.
 */

export const CITIES = {
  'West Bengal':      ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri', 'Kharagpur'],
  'Maharashtra':      ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Aurangabad', 'Thane'],
  'Karnataka':        ['Bengaluru', 'Mysuru', 'Hubli', 'Mangaluru', 'Belagavi'],
  'Tamil Nadu':       ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem'],
  'Delhi':            ['New Delhi', 'Dwarka', 'Noida', 'Gurgaon', 'Faridabad'],
  'Uttar Pradesh':    ['Lucknow', 'Kanpur', 'Varanasi', 'Agra', 'Prayagraj', 'Ghaziabad'],
  'Rajasthan':        ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Bikaner'],
  'Gujarat':          ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Gandhinagar'],
  'Madhya Pradesh':   ['Bhopal', 'Indore', 'Gwalior', 'Jabalpur', 'Ujjain'],
  'Punjab':           ['Chandigarh', 'Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala'],
  'Haryana':          ['Gurugram', 'Faridabad', 'Panipat', 'Ambala', 'Rohtak'],
  'Andhra Pradesh':   ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Tirupati'],
  'Telangana':        ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar'],
  'Kerala':           ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam'],
  'Bihar':            ['Patna', 'Gaya', 'Muzaffarpur', 'Bhagalpur'],
  'Odisha':           ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Berhampur'],
  'Assam':            ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat'],
  'Jharkhand':        ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro'],
  'Chhattisgarh':     ['Raipur', 'Bhilai', 'Bilaspur', 'Korba'],
  'Goa':              ['Panaji', 'Margao', 'Vasco da Gama'],
  'Himachal Pradesh': ['Shimla', 'Manali', 'Dharamshala', 'Solan'],
  'Uttarakhand':      ['Dehradun', 'Haridwar', 'Rishikesh', 'Nainital'],
  'Chandigarh':       ['Chandigarh'],
  'J&K':              ['Jammu', 'Srinagar', 'Leh'],
};

/** All state names in display order */
export const STATES = Object.keys(CITIES);
